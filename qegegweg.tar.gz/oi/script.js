let colecaoMidia = [];
let idItemSendoEditado = null; 

// 1. CARREGAR DADOS (DO LOCALSTORAGE OU DO ARQUIVO JSON INICIAL)
async function carregarCatalogo() {
  const container_card = document.getElementById('catalogo-grid');
  container_card.innerHTML = `<p>Carregando itens, aguarde...</p>`;
  try {
    const dadosLocais = localStorage.getItem('dadosMidia');
    if (dadosLocais) {
      colecaoMidia = JSON.parse(dadosLocais);
    } else {
      const resposta = await fetch('dados.json');
      if (!resposta.ok) throw new Error('Arquivo dados.json não encontrado na pasta.');
      colecaoMidia = await resposta.json();
      localStorage.setItem('dadosMidia', JSON.stringify(colecaoMidia));
    }
    rendenizarGrid(colecaoMidia);
    configurarFiltros();
  } catch (erro) {
    container_card.innerHTML = `<p style="color: #ef4444;">Erro ao carregar catálogo: ${erro.message}</p>`;
    console.error(erro);
    configurarFiltros();
  }
}

// 2. RENDERIZAR OS CARDS
function rendenizarGrid(lista) {
  const container = document.getElementById('catalogo-grid');
  container.innerHTML = '';
  
  if (lista.length === 0) {
    container.innerHTML = `<p class="info" style="grid-column: 1/-1; text-align: center; padding: 20px;">Nenhum item cadastrado nesta categoria</p>`;
    return;
  }
  
  lista.forEach(item => {
    const card = document.createElement('div');
    card.className = 'card';
    const notaFormatada = Number(item.nota).toFixed(1);
    const linkImagem = item.capa || item.imagem || item.imagemUrl || '';
    const urlCapa = linkImagem.trim() !== '' 
      ? linkImagem 
      : 'https://placehold.co/300x450/1e293b/f8fafc?text=Sem+Capa';
    
    card.innerHTML = `
      <div class="capa-container">
         <a href="detalhes.html?id=${item.id}">
          <img 
            src="${urlCapa}" 
            onerror="this.onerror=null; this.src='https://placehold.co/300x450/1e293b/ef4444?text=Imagem+Invalida';" 
            alt="${item.titulo}" 
            class="capa-midia" 
            style="cursor: pointer; display: block; width: 100%;"
          >
        </a>
      </div>
      <div class="card-content" style="display: flex; flex-direction: column; justify-content: space-between; height: 100%;">
        <div>
          <span class="tag-categoria">${item.categoria}</span>
          <h3>${item.titulo}</h3>
          <p class="info">Plataforma: <strong>${item.plataforma}</strong></p>
          <p class="info">Status: <strong class="status-badge" onclick="alterarStatus('${item.id}')" style="cursor:pointer;">${item.status || 'Disponível'}</strong></p>
          <div class="nota-container" style="margin-bottom: 15px;">
            <i class="fa-solid fa-star"></i>
            <span>${notaFormatada}</span>
          </div>
        </div>
        
        <div style="display: flex; gap: 8px; margin-top: auto;">
          <button onclick="carregarParaEdicao('${item.id}')" style="flex: 1; background-color: #0ea5e9; color: #f8fafc; border: none; padding: 8px 12px; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 13px; display: flex; align-items: center; justify-content: center; gap: 6px; transition: all 0.2s ease;" onmouseover="this.style.backgroundColor='#0284c7'" onmouseout="this.style.backgroundColor='#0ea5e9'">
            <i class="fa-solid fa-pen-to-square"></i> Editar
          </button>

          <button onclick="excluirItem('${item.id}')" style="flex: 1; background-color: #334155; color: #f8fafc; border: none; padding: 8px 12px; border-radius: 6px; cursor: pointer; font-weight: 600; font-size: 13px; display: flex; align-items: center; justify-content: center; gap: 6px; transition: all 0.2s ease;" onmouseover="this.style.backgroundColor='#ef4444'" onmouseout="this.style.backgroundColor='#334155'">
            <i class="fa-solid fa-trash-can"></i> Excluir
          </button>
        </div>
      </div>
    `;
    container.appendChild(card);
  });
}

// 3. EVENTO DO FORMULÁRIO UNIFICADO
document.getElementById('form-midia').addEventListener('submit', function(evento) {
  evento.preventDefault();
  
  const titulo = document.getElementById('titulo').value;
  const imagemUrl = document.getElementById('imagemUrl').value;
  const categorySelect = document.getElementById('categoria');
  const categoria = categorySelect ? categorySelect.value : '';
  const plataforma = document.getElementById('plataforma').value;
  const nota = parseFloat(document.getElementById('nota').value);
  
  if (idItemSendoEditado !== null) {
    const itemIndex = colecaoMidia.findIndex(m => String(m.id) === String(idItemSendoEditado));
    
    if (itemIndex !== -1) {
      colecaoMidia[itemIndex].titulo = titulo;
      colecaoMidia[itemIndex].capa = imagemUrl;
      colecaoMidia[itemIndex].categoria = categoria;
      colecaoMidia[itemIndex].plataforma = plataforma;
      colecaoMidia[itemIndex].nota = nota;
    }
    
    idItemSendoEditado = null;
    const botaoAdicionar = this.querySelector('button[type="submit"]');
    if (botaoAdicionar) botaoAdicionar.textContent = 'Adicionar';
    alert('Item atualizado com sucesso!');
    
  } else {
    const novoItem = {
      id: String(Date.now()),
      titulo: titulo,
      categoria: categoria,
      plataforma: plataforma,
      nota: parseFloat(nota),
      status: categoria === "Jogos" ? "Jogado" : "Assistido",
      capa: imagemUrl
    };
    colecaoMidia.push(novoItem);
    alert('Item adicionado à lista local com sucesso!');
  }
  
  localStorage.setItem('dadosMidia', JSON.stringify(colecaoMidia));
  rendenizarGrid(colecaoMidia);
  this.reset();
});

// 4. PUXA OS DADOS DO CARD PARA O FORMULÁRIO
function carregarParaEdicao(id) {
  const item = colecaoMidia.find(m => String(m.id) === String(id));
  if (!item) return;
  
  document.getElementById('titulo').value = item.titulo;
  document.getElementById('imagemUrl').value = item.capa || '';
  if (document.getElementById('categoria')) document.getElementById('categoria').value = item.categoria;
  document.getElementById('plataforma').value = item.plataforma || '';
  document.getElementById('nota').value = item.nota;
  
  idItemSendoEditado = id;
  
  const botaoAdicionar = document.querySelector('#form-midia button[type="submit"]');
  if (botaoAdicionar) {
    botaoAdicionar.textContent = 'Salvar Alterações';
  }
  
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

// 5. CONFIGURAR OS BOTÕES DE FILTRO
function configurarFiltros() {
  const botoes = document.querySelectorAll('.filtros button');
  botoes.forEach(botao => {
    botao.addEventListener('click', () => {
      const categoriaSelecionada = botao.textContent.trim();
      if (categoriaSelecionada === 'Todos') {
        rendenizarGrid(colecaoMidia);
      } else {
        const listaFiltrada = colecaoMidia.filter(item => {
          const catItem = item.categoria.toLowerCase();
          const catBotao = categoriaSelecionada.toLowerCase();
          return catItem.startsWith(catBotao.substring(0, 4));
        });
        rendenizarGrid(listaFiltrada);
      }
    });
  });
}

// 6. ALTERAR STATUS SEQUENCIALMENTE
async function alterarStatus(id) {
  const item = colecaoMidia.find(m => String(m.id) === String(id));
  if(!item) return;
  
  const statusOpcoes = ["Jogar", "Jogando", "Jogado", "Assistir", "Assistindo", "Assistido"];
  const indexAtual = statusOpcoes.indexOf(item.status);
  const proximoStatus = statusOpcoes[(indexAtual + 1) % statusOpcoes.length];
  
  try {
    item.status = proximoStatus;
    localStorage.setItem('dadosMidia', JSON.stringify(colecaoMidia));
    rendenizarGrid(colecaoMidia);
  } catch(erro) {
    alert("Erro ao atualizar o status");
  }
}

// 7. FUNÇÃO PARA EXCLUIR O CARD COMPLETO
function excluirItem(id) {
  const item = colecaoMidia.find(m => String(m.id) === String(id));
  if (!item) {
    alert("Item não encontrado para exclusão.");
    return;
  }
  if (confirm(`Deseja realmente apagar o card de "${item.titulo}" e remover tudo?`)) {
    colecaoMidia = colecaoMidia.filter(m => String(m.id) !== String(id));
    localStorage.setItem('dadosMidia', JSON.stringify(colecaoMidia));
    rendenizarGrid(colecaoMidia);
  }
}

document.addEventListener('DOMContentLoaded', carregarCatalogo);